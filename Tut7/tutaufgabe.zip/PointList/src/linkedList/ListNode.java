package linkedList;

public class ListNode {

	private Point point;
	private ListNode next;
	
	public ListNode(Point content, ListNode next) {
		this.setPoint(content);
		this.setNext(next);
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

	public ListNode getNext() {
		return next;
	}

	public void setNext(ListNode next) {
		this.next = next;
	}

	
	
	
}
