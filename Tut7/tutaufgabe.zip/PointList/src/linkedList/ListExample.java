package linkedList;

public class ListExample {
	
	public static void main(String[] args) {
		LinkedPointList list = new LinkedPointList(new ListNode(new Point(0,1), null));
		int x = 0;
		int y = 1;
		
		for(int i = 0; i < 20; i++) {
			list.addLast(new Point(x,y));
			x++;
			y++;
		}
		list.remove(3);
		System.out.println(list);
	}
}
