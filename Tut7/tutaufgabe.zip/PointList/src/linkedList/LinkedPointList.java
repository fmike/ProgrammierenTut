package linkedList;

public class LinkedPointList {

	private ListNode head;
	
	public LinkedPointList(ListNode head) {
		this.head = head;
	}
	
	public void add(Point p, int index) {
		ListNode tmp = head;
		
		for(int i = 0; i < index; i++) {
			if(tmp.getNext() == null) {
				break;
			} else {
				tmp = tmp.getNext();
			}
		}
		
		tmp.setNext(new ListNode(p, null));
	}
	
	public void addFirst(Point p) {
		ListNode first = new ListNode(p, head);
		head = first;
	}
	
	public void addLast(Point p) {
		ListNode tmp = head;
		
		while(tmp.getNext() != null) {
			tmp = tmp.getNext();
		}
		
		tmp.setNext(new ListNode(p, null));
	}
	
	public boolean contains(Point p) {
		ListNode tmp = head;

		while(tmp.getNext() != null) {
			
			if(tmp.getPoint().equals(p)) {
				return true;
			}
			tmp = tmp.getNext();
		}
		return false;
	}
	
	public Point get(int index) {

		ListNode tmp = head;
		
		for(int i = 0; i < index; i++) {
			if(tmp.getNext() == null) {
				return null;
			} else {
				tmp = tmp.getNext();
			}
		}
		
		return tmp.getPoint();
	}
	
	public boolean isEmpty() {
		return head == null;
	}
	
	public void remove(int index) {
		ListNode tmp = head;
		
		for(int i = 0; i < (index - 1); i++) {
			if(tmp.getNext() == null) {
				return;
			} else {
				tmp = tmp.getNext();
			}
		}
		
		tmp.setNext(tmp.getNext().getNext());
	}
	
	public String toString() {
        ListNode tmp = head;
        String res = "[ ";
		
		while(tmp.getNext() != null) {
			res += tmp.getPoint().toString();
			tmp = tmp.getNext();
		}
		
		res += " ]";
		return res;
	}
}
