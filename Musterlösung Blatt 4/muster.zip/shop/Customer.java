package shop;

import lists.OrderList;

/**
 * Represents a customer that places or placed
 * orders at the OnlineShop
 * @author Mischa Carl
 * @version 1.0
 */
public class Customer {

    private String name;
    private String adress;
    private OrderList orders;

    /**
     * Creates a new Customer entry with a givne name
     * and a given adress
     * @param name given name
     * @param adress given adress
     */
    public Customer(String name, String adress) {
        this.name = name;
        this.adress = adress;
        this.orders = new OrderList();
    }
    
    /**
     * Returns the name of the customer
     * @return the name of the customer
     */
    public String getName() {
        return name;
    }
    
    /**
     * Returns the adress of the customer
     * @return the adress of the customer
     */
    public String getAdress() {
        return adress;
    }
    
    /**
     * Returns the list of orders the customer has placed
     * @return the list of oerders
     */
    public OrderList getOrders() {
        return orders;
    }
    
    /**
     * Changes the name of the customer to a given one
     * @param name given name 
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Changes the adress of the customer to a given one
     * @param adress given adress
     */
    public void setAdress(String adress) {
        this.adress = adress;
    }
    
    @Override
    public boolean equals(Object o) {
        return (o instanceof Customer 
                && ((this.name.equals(((Customer) o).getName())) && (this.adress.equals(((Customer) o).getAdress()))));
    }

    @Override
    public String toString() {
        return name + "\n" + adress;
    }

}
