package shop;

import graph.Graph;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import lists.CustomerList;

/**
 * Models an OnlineShop that is based upon a passed
 * list of orders
 * @author Mischa Carl
 * @version 9001
 */
public class OnlineShop {

    private static final String USAGE = "path to a list of orders has to be passed as argument";
    private static final String ERROR_MESSAGE = "shit be whack yo!";

    private CustomerList customers;
    private Graph graph;

    /**
     * Creates a new OnlineShop
     */
    public OnlineShop() {
        this.customers = new CustomerList();
    }

    /**
     * Used for testing of the onlineshop
     * @param args used to pass the path to the file
     */
    public static void main(String[] args) {
        OnlineShop shop = new OnlineShop();
        shop.setGraph(new Graph());

        if (args.length != 1) {
            System.out.println(USAGE);
            System.exit(1);
        }
        FileReader in = null;
        try {
            in = new FileReader(args[0]);
        } catch (FileNotFoundException e) {
            System.out.println(ERROR_MESSAGE);
            System.exit(1);
        }
        BufferedReader reader = new BufferedReader(in);
        try {
            String line = reader.readLine();
            while (line != null) {

                String[] tokens = line.split(";");
                if (tokens.length == 5) { //ignore malformed orders
                    shop.processTokens(tokens);
                } 
                line = reader.readLine();
            }
            shop.print();
            // System.out.println(shop.toString());
            System.out.println("***");

            for (int i = 0; i < shop.getCustomer().size(); i++) {
                for (int j = 0; j < shop.getCustomer().get(i).getOrders().size(); j++) {
                    shop.getGraph().addOrder(shop.getCustomer().get(i).getOrders().get(j));
                }
            }

            shop.getGraph().print();
        } catch (IOException e) {
            System.out.println(ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void setGraph(Graph graph) {
        this.graph = graph;  
    }

    private Graph getGraph() {
        return graph;  
    }

    private CustomerList getCustomer() {
        return customers;  
    }

    private void processTokens(String[] tokens) {

        String name = tokens[0];
        String adress = tokens[1];
        String orderNumber = tokens[2];
        String articleName = tokens[3];
        String price = tokens[4];


        Customer customer = new Customer(name, adress);
        Order order = new Order(orderNumber);
        Article article = new Article(articleName, price);

        Customer checkCustomer = customers.get(customer);
        if (checkCustomer != null) {
            //customer is already known
            Order checkOrder = checkCustomer.getOrders().get(orderNumber);
            if (checkOrder != null) {
                //the article is part of an order that already exists
                checkOrder.getArticles().add(article);
            } else {
                //there is no such order yet
                order.getArticles().add(article);
                checkCustomer.getOrders().add(order);
            }
        } else {
            //customer is not yet known
            order.getArticles().add(article);
            customer
            .getOrders()
            .add(order);
            customers.addFirst(customer);
        }
    }

    /**
     * Prints the contents of the Onlineshop to the console in an orderly fashion
     */
    public void print() {
        for (int i = 0; i < customers.size(); i++) {
            Customer current = customers.get(i);
            System.out.println(current.toString());
            for (int j = 0; j < current.getOrders().size(); j++) {
                System.out.print("\n");
                Order order = current.getOrders().get(j);
                System.out.println(order.toString());
                for (int k = 0; k < order.getArticles().size(); k++) {
                    Article article = order.getArticles().get(k);
                    System.out.println(article.toString());
                }
            }
            System.out.println("---");
        }
    }

    @Override
    public String toString() {
        return customers.toString();
    }
}
