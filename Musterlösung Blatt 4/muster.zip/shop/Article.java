package shop;

/**
 * Models an Article to be sold in the onlineshop
 * @author Mischa Carl
 * @version 1.0
 */
public class Article {

    private String name;
    private String price;

    /**
     * Creates a new Article with a given name 
     * and Price
     * @param name given Name
     * @param price given Price
     */
    public Article(String name, String price) {
        this.name = name;
        this.price = price;
    }

    /**
     * Returns the name of the Article
     * @return the name of the Article 
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the price of the Article
     * @return the price of the Article
     */
    public String getPrice() {
        return price;
    }

    /**
     * Sets the name of the article to a given one
     * @param name given name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the Price of the Article to a given one
     * @param price given price
     */
    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof Article 
                && (this.name.equals(((Article) o).getName())) && (this.getPrice().equals(((Article) o).getPrice())));
    }
    
    @Override
    public String toString() {
        return this.getName();
    }
}
