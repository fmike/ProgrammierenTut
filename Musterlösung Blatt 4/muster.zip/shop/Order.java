package shop;

import lists.ArticleList;

/**
 * Represents an order with a list of 
 * Articles
 * @author Mischa Carl
 * @version 1.0
 */
public class Order {

    private ArticleList articles;
    private String orderCode;

    /**
     * Creats a new order with a given orderCode
     * @param orderCode given orderCode
     */
    public Order(String orderCode) {
        this.orderCode = orderCode;
        this.articles = new ArticleList();
    }
    
    /**
     * Returns the articles of this order
     * @return the articles of this order
     */
    public ArticleList getArticles() {
        return articles;
    }
    
    /**
     * Returns the orderCode of this order 
     * @return the orderCode of this order
     */
    public String getOrderCode() {
        return orderCode;
    }
    
    /**
     * Sets the orderCode to a given orderCode
     * @param orderCode given orderCode
     */
    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    @Override
    public String toString() {
        return this.orderCode;
    }

    @Override
    public boolean equals(Object  o) {
        return ((o instanceof Order) && (this.orderCode.equals(((Order) o).getOrderCode())));
    }

}
