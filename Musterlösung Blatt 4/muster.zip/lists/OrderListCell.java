package lists;

import shop.Order;

/**
 * Represents a cell of the OrderList
 * @author Mischa Carl
 * @version 1.0
 */
public class OrderListCell {

    /** The next element in the list*/
    private OrderListCell next;
    /** The Order contained in this cell*/
    private Order content;

    /**
     * Creates a new Cell with a given Order as content
     * @param content given Order
     */
    public OrderListCell(Order content) {
        this.content = content;
    }

    /**
     * Checks whether the list has another element
     * after this one
     * @return whether the list has another element
     */
    public boolean hasNext() {
        return next != null;
    }

    /**
     * Returns the next element of the list or null if it has none
     * @return the next element of the list or null
     */
    public OrderListCell getNext() {
        return next;
    }

    /**
     * Returns the content of this cell 
     * @return the content of this cell
     */
    public Order getContent() {
        return content;
    }
    
    /**
     * Sets the next element of the list to a given element
     * @param next given element
     */
    public void setNext(OrderListCell next) {
        this.next = next;
    }

    /**
     * Sets the content of this cell to a given Order
     * @param content given Order
     */
    public void setContent(Order content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content.toString();
    }


}
