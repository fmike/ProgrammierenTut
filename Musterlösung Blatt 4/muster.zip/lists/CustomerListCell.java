package lists;

import shop.Customer;

/**
 * Represents a cell of the ArticleList
 * @author Mischa Carl
 * @version 1.0
 */
public class CustomerListCell {

    /** The next element in the list*/
    private CustomerListCell next;
    /** The Customer contained in this cell*/
    private Customer content;
    
    /**
     * Creates a new Cell with a given Customer as content
     * @param content given Article
     */
    public CustomerListCell(Customer content) {
        this.content = content;
    }
    
    /**
     * Checks whether the list has another element
     * after this one
     * @return whether the list has another element
     */
    public boolean hasNext() {
        return next != null;
    }
    
    /**
     * Returns the next element of the list or null if it has none
     * @return the next element of the list or null
     */
    public CustomerListCell getNext() {
        return next;
    }
    
    /**
     * Returns the content of this cell 
     * @return the content of this cell
     */
    public Customer getContent() {
        return content;
    }

    /**
     * Sets the next element of the list to a given element
     * @param next given element
     */
    public void setNext(CustomerListCell next) {
        this.next = next;
    }

    /**
     * Sets the content of this cell to a given Article
     * @param content given Article
     */
    public void setContent(Customer content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content.toString();
    }


}
