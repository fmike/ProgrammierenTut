package lists;

import shop.Customer;

/**
 * Provides an implementation of a single linked list 
 * able to contain Customers 
 * @author Void
 * @version 1.0
 */
public class CustomerList {

    /** First element of the list */
    private CustomerListCell head;

    /**
     * Creates a new, empty CustomerList
     */
    public CustomerList() {
    }
    
    /**
     * Adds a given Customer to the end of the list
     * @param c given Customer
     */
    public void add(Customer c) {
        CustomerListCell add = new CustomerListCell(c);
        if (isEmpty()) {
            head = add;
        } else {
            CustomerListCell temp = head;
            while (temp.hasNext()) {
                temp = temp.getNext();
            }
            temp.setNext(add);
        }
    }
    
    /**
     * Adds a given Customer to the head of the list
     * @param c given Customer
     */
    public void addFirst(Customer c) {
        CustomerListCell add = new CustomerListCell(c);
        if (!isEmpty()) {
            add.setNext(head);
        } 
        head = add;
    }
    
    /**
     * Checks if a given Customer is in the list 
     * and returns it if so, returns null otherwise
     * @param c given Customer
     * @return the Customer or null
     */
    public Customer get(Customer c) {
        Customer ret = null;

        boolean found = false;
        CustomerListCell temp = head;
        while (temp != null && !found) {
            if (c.equals(temp.getContent())) {
                ret = temp.getContent();
                found = true;
            } else {
                temp = temp.getNext();
            }
        }
        return ret;
    }
    
    /**
     * Checks whether the list is empty
     * @return whether the list is empty
     */
    public boolean isEmpty() {
        return head == null;
    }
    
    @Override
    public String toString() {
        String ret = "";
        if (!isEmpty()) {
            CustomerListCell temp = head;
            while (temp != null) {
                ret += temp.toString() + "\n";
                temp = temp.getNext();
            }
        }
        return ret;
    }
    
    /**
     * Returns the number of customers in this list
     * 
     * @return the number of customers in this list
     */
    public int size() {
        int i = 0;
        CustomerListCell alc = head;
        while (alc != null) {
            i++;
            alc = alc.getNext();
        }
        return i;
    }
    
    /**
     * Returns the i-th customer in the list or null (i starts at 0, as usual)
     * 
     * @param i the index of the customer
     * @return the customer
     */
    public Customer get(int i) {
        if (i < 0 || i >= size()) {
            return null;
        }
        CustomerListCell alc = head;
        int counter = i;
        while (counter > 0) {
            alc = alc.getNext();
            counter--;
        }
        return alc.getContent();
    }

}
