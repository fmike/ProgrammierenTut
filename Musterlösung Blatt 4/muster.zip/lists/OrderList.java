package lists;

import shop.Order;

/**
 * Provides an implementation of a single linked list 
 * able to contain Articles 
 * @author Mischa Carl
 * @version 1.0
 */
public class OrderList {

    /** First element of the list */
    private OrderListCell head;

    /**
     * Creates a new, empty OrderList
     */
    public OrderList() {
    }

    /**
     * Adds a given Order to the end of the list
     * @param o given Order
     */
    public void add(Order o) {
        OrderListCell add = new OrderListCell(o);
        if (isEmpty()) {
            head = add;
        } else {
            OrderListCell temp = head;
            while (temp.hasNext()) {
                temp = temp.getNext();
            }
            temp.setNext(add);
        }
    }

    /**
     * Checks if a given OrderCode is in the list 
     * and returns the according order if so,
     * returns null otherwise
     * @param orderCode given OrderCode
     * @return the Order or null
     */
    public Order get(String orderCode) {
        Order ret = null;

        boolean found = false;
        OrderListCell temp = head;
        while (temp != null && !found) {
            if (orderCode.equals((temp.getContent().getOrderCode()))) {
                ret = temp.getContent();
                found = true;
            } else {
                temp = temp.getNext();
            }
        }
        return ret;
    }
    
    /**
     * Checks whether the list is empty
     * @return whether the list is empty
     */
    public boolean isEmpty() {
        return head == null;
    }
    
    @Override
    public String toString() {
        String ret = "\n";
        if (!isEmpty()) {
            OrderListCell temp = head;
            while (temp != null) {
                ret += temp.toString();
                if (temp.hasNext()) {
                    ret += "\n";
                }
                temp = temp.getNext();
            }
        }
        return ret;
    }
    
    /**
     * Returns the number of orders in this list
     * 
     * @return the number of orders in this list
     */
    public int size() {
        int i = 0;
        OrderListCell alc = head;
        while (alc != null) {
            i++;
            alc = alc.getNext();
        }
        return i;
    }
    
    /**
     * Returns the i-th order in the list or null (i starts at 0, as usual)
     * 
     * @param i the index of the order
     * @return the order
     */
    public Order get(int i) {
        if (i < 0 || i >= size()) {
            return null;
        }
        OrderListCell alc = head;
        int counter = i;
        while (counter > 0) {
            alc = alc.getNext();
            counter--;
        }
        return alc.getContent();
    }

}
