package lists;

import shop.Article;

/**
 * Provides an implementation of a single linked list 
 * able to contain Articles 
 * @author Mischa Carl
 * @version 1.0
 */
public class ArticleList {

    /** First element of the list */
    private ArticleListCell head;

    /**
     * Creates a new, empty ArticleList
     */
    public ArticleList() {
    }

    /**
     * Adds a given Article to the end of the list
     * @param a given Article
     */
    public void add(Article a) {
        ArticleListCell add = new ArticleListCell(a);
        if (isEmpty()) {
            head = add;
        } else {
            ArticleListCell temp = head;
            while (temp.hasNext()) {
                temp = temp.getNext();
            }
            temp.setNext(add);
        }
    }

    /**
     * Checks if a given Article is in the list 
     * and returns it if so, returns null otherwise
     * @param a given Article
     * @return the Article or null
     */
    public ArticleListCell get(Article a) {
        ArticleListCell ret = null;

        boolean found = false;
        ArticleListCell temp = head;
        while (temp != null && !found) {
            if (a.equals(temp.getContent())) {
                ret = temp;
                found = true;
            } else {
                temp = temp.getNext();
            }
        }
        return ret;
    }

    /**
     * Checks whether the list is empty
     * @return whether the list is empty
     */
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public String toString() {
        String ret = "";
        if (!isEmpty()) {
            ArticleListCell temp = head;
            while (temp != null) {
                ret += temp.toString() + "\n";
                temp = temp.getNext();
            }
        }
        return ret;
    }

    /**
     * Returns the number of articles in this list
     * 
     * @return the number of articles in this list
     */
    public int size() {
        int i = 0;
        ArticleListCell alc = head;
        while (alc != null) {
            i++;
            alc = alc.getNext();
        }
        return i;
    }
    
    /**
     * Returns the i-th article in the list or null (i starts at 0, as usual)
     * 
     * @param i the index of the article
     * @return the article
     */
    public Article get(int i) {
        if (i < 0 || i >= size()) {
            return null;
        }
        ArticleListCell alc = head;
        int counter = i;
        while (counter > 0) {
            alc = alc.getNext();
            counter--;
        }
        return alc.getContent();
    }
}
