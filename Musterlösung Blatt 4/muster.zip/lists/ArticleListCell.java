package lists;

import shop.Article;

/**
 * Represents a cell of the ArticleList
 * @author Mischa Carl
 * @version 1.0
 */
public class ArticleListCell {

    /** The next element in the list*/
    private ArticleListCell next;
    /** The article contained in this cell*/
    private Article content;

    /**
     * Creates a new Cell with a given Article as content
     * @param content given Article
     */
    public ArticleListCell(Article content) {
        this.content = content;
    }

    /**
     * Checks whether the list has another element
     * after this one
     * @return whether the list has another element
     */
    public boolean hasNext() {
        return next != null;
    }

    /**
     * Returns the next element of the list or null if it has none
     * @return the next element of the list or null
     */
    public ArticleListCell getNext() {
        return next;
    }

    /**
     * Returns the content of this cell 
     * @return the content of this cell
     */
    public Article getContent() {
        return content;
    }

    /**
     * Sets the next element of the list to a given element
     * @param next given element
     */
    public void setNext(ArticleListCell next) {
        this.next = next;
    }

    /**
     * Sets the content of this cell to a given Article
     * @param content given Article
     */
    public void setContent(Article content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content.toString();
    }


}
