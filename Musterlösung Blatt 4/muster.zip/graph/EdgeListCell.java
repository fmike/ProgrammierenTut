package graph;


/**
 * Represents a cell of the ArticleList
 * @author Mischa Carl
 * @version 1.0
 */
public class EdgeListCell {

    /** The next element in the list*/
    private EdgeListCell next;
    /** The Edge contained in this cell*/
    private Edge content;
    
    /**
     * Creates a new Cell with a given Edge as content
     * @param content given Article
     */
    public EdgeListCell(Edge content) {
        this.content = content;
    }
    
    /**
     * Checks whether the list has another element
     * after this one
     * @return whether the list has another element
     */
    public boolean hasNext() {
        return next != null;
    }
    
    /**
     * Returns the next element of the list or null if it has none
     * @return the next element of the list or null
     */
    public EdgeListCell getNext() {
        return next;
    }
    
    /**
     * Returns the content of this cell 
     * @return the content of this cell
     */
    public Edge getContent() {
        return content;
    }

    /**
     * Sets the next element of the list to a given element
     * @param next given element
     */
    public void setNext(EdgeListCell next) {
        this.next = next;
    }

    /**
     * Sets the content of this cell to a given Article
     * @param content given Article
     */
    public void setContent(Edge content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content.toString();
    }


}
