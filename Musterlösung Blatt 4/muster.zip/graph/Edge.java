package graph;

import shop.Article;

/**
 * An Edge in a Graph of Articles
 * 
 * @author alina
 * @version 1.0
 *
 */
public class Edge {

    private Article article1;
    private Article article2;
    private int weight;

    /**
     * Constructs a Edge between two articles
     * 
     * @param article1 first article
     * @param article2 second article
     */
    public Edge(Article article1, Article article2) {
        this.weight = 1;
        this.article1 = article1;
        this.article2 = article2;
    }

    /**
     * Returns the first article connected to this Edge
     * 
     * @return first article
     */
    public Article getArticle1() {
        return article1;
    }

    /**
     * Returns the second article connected to this Edge
     * 
     * @return second article
     */
    public Article getArticle2() {
        return article2;
    }

    private boolean equals(Edge other) {
        if (other == null) {
            return false;
        }
        if (this.article1.equals(other.article1) && this.article2.equals(other.article2)) {
            return true;
        } else if (this.article1.equals(other.article2) && this.article2.equals(other.article1)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Edge)) {
            return false;
        } else {
            return equals((Edge) other);
        }
    }
    
    /**
     * Setter for the weight of this edge
     * 
     * @param weight the new weight
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }
    
    /**
     * Getter for the weight of this edge
     * 
     * @return the weight
     */
    public int getWeight() {
        return weight;
    }
}
