package graph;

import lists.ArticleList;
import shop.Article;
import shop.Order;

/**
 * Provides an implementation of a single linked list 
 * able to contain Edges
 * Based on lists.CustomerList 
 * @author Void
 * @version 1.0
 */
public class Graph {

    /** First element of the list */
    private EdgeListCell head;
    
    private ArticleList articles;

    /**
     * Creates a new, empty EdgeList
     */
    public Graph() {
        articles = new ArticleList();
    }

    /**
     * Adds a given Edge to the end of the list
     * @param c given Edge
     */
    public void add(Edge c) {
        Edge got = get(c);
        if (got == null) {
            EdgeListCell add = new EdgeListCell(c);
            if (isEmpty()) {
                head = add;
            } else {
                EdgeListCell temp = head;
                while (temp.hasNext()) {
                    temp = temp.getNext();
                }
                temp.setNext(add);
            }
            if (articles.get(c.getArticle1()) == null) {
                articles.add(c.getArticle1());
            }
            if (articles.get(c.getArticle2()) == null) {
                articles.add(c.getArticle2());
            }
        } else {
            got.setWeight(got.getWeight() + 1);
        }
    }

    /**
     * Checks if a given Edge is in the list 
     * and returns it if so, returns null otherwise
     * @param c given Edge
     * @return the Edge or null
     */
    public Edge get(Edge c) {
        Edge ret = null;

        boolean found = false;
        EdgeListCell temp = head;
        while (temp != null && !found) {
            if (c.equals(temp.getContent())) {
                ret = temp.getContent();
                found = true;
            } else {
                temp = temp.getNext();
            }
        }
        return ret;
    }

    /**
     * Checks whether the list is empty
     * @return whether the list is empty
     */
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public String toString() {
        String ret = "";
        if (!isEmpty()) {
            EdgeListCell temp = head;
            while (temp != null) {
                ret += temp.toString() + "\n";
                temp = temp.getNext();
            }
        }
        return ret;
    }
    
    /**
     * Returns a graph, containing only article and Articles connected to it.
     * 
     * @param article the article
     * @return a new graph
     */
    public Graph neighbourhood(Article article) {
        Graph neighbours = new Graph();
        EdgeListCell elc = head;
        while (elc != null) {
            if (elc.getContent().getArticle1().equals(article) || elc.getContent().getArticle2().equals(article)) {
                neighbours.add(elc.getContent());
            }
            elc = elc.getNext();
        }
        return neighbours;
    }
    
    /**
     * Returns the edge with maximum weight. Returns null, if no edge could be found
     * 
     * @return the edge with maximum weight or null
     */
    public Edge getMaximum() {
        Edge max = null;
        int maxWeight = 0;

        EdgeListCell elc = head;
        while (elc != null) {
            if (elc.getContent().getWeight() > maxWeight) {
                maxWeight = elc.getContent().getWeight();
                max = elc.getContent();
            }
            elc = elc.getNext();
        }
        return max;
    }
    
    /**
     * Adds an order to the graph. For each pair of articles in the order a new Edge is generated and added to
     * this graph.
     * 
     * @param order the order to process
     */
    public void addOrder(Order order) {
        ArticleList articles = order.getArticles();
        for (int i = 0; i < articles.size(); i++) {
            for (int j = i + 1; j < articles.size(); j++) {
                add(new Edge(articles.get(i), articles.get(j)));
            }
            if (this.articles.get(articles.get(i)) == null) {
                this.articles.add(articles.get(i));
            }
        }
    }
    
    /**
     * Prints this Graph in the fashion described in the tasks
     */
    public void print() {
        for (int i = 0; i < articles.size(); i++) {
            Article article = articles.get(i);
            System.out.print(article.getName() + ":");
            Edge edge = neighbourhood(article).getMaximum();
            if (edge != null) {
                if (edge.getArticle1() == article) {
                    System.out.println(edge.getArticle2());
                } else {
                    System.out.println(edge.getArticle1());
                }
            }
        }
    }

}
