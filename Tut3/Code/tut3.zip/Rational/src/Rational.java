/* Der Stand, den wir bisher haben, um vielleicht weiter zu experimentieren ;) */
public class Rational {
	private int numerator;
	private int denominator;
	
	public Rational(int numerator, int denominator) {
		
		this.numerator = numerator;
		this.denominator = denominator;
		
	}
	
	public Rational add(Rational r) {
		
		Rational result;
		
		if(this.denominator == r.denominator) {
			result = new Rational(this.numerator + r.numerator, this.denominator);
		} else {
			int newDenominator = this.denominator * r.denominator;
			int newNumerator = this.numerator * r.denominator + this.denominator * r.numerator; 
			result = new Rational(newNumerator, newDenominator);
		}
		
		return result;
	}
	
	public Rational add(int x) {
		return new Rational(this.numerator + (x * this.denominator), this.denominator);
	}
	
	public String toString() {
		return this.numerator + "/" + this.denominator;
	}
	
	public static void main(String[] args) {
		Rational r = new Rational(1,4);
		Rational s = new Rational(2,5);
		Rational q = r.add(s);
		System.out.println(q); //toString wird automatisch aufgerufen
		//d.h. System.out.println(q.toString()); steht da praktisch
	}
	
}
